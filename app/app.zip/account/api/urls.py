from django.urls import path
from . import views

app_name = 'account'

urlpatterns = [
    path('accounts/',views.BankAccountListView.as_view(), name='account_list'),
    path('accounts/<pk>/', views.BankAccountDetailView.as_view(), name='account_detail'),
]