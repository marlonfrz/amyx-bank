from django.urls import path
from . import views

app_name = 'card'

urlpatterns = [
    path('cards/',views.CardListView.as_view(), name='card_list'),
    path('cards/<pk>/', views.CardDetailView.as_view(), name='card_detail'),
]